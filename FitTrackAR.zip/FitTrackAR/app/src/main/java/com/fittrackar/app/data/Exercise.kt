package com.fittrackar.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,           // "Push-up", "Squat" və s.
    val targetReps: Int,        // Məs: 10
    var completedReps: Int = 0,
    var isCompleted: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis()
)
