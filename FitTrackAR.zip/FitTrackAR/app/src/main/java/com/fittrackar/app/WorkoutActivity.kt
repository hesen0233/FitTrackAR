package com.fittrackar.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.fittrackar.app.data.AppDatabase
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class WorkoutActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlayView: PoseOverlayView
    private lateinit var tvRepCount: TextView
    private lateinit var tvTarget: TextView
    private lateinit var tvFeedback: TextView

    private lateinit var poseHelper: PoseLandmarkerHelper
    private lateinit var repCounter: PushUpCounter
    private lateinit var cameraExecutor: ExecutorService

    private var exerciseId: Int = -1
    private var targetReps: Int = 10
    private lateinit var db: AppDatabase

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Kamera icazəsi lazımdır", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout)

        exerciseId = intent.getIntExtra("exercise_id", -1)
        targetReps = intent.getIntExtra("target_reps", 10)
        val exerciseName = intent.getStringExtra("exercise_name") ?: "Push-up"

        previewView = findViewById(R.id.previewView)
        overlayView = findViewById(R.id.overlayView)
        tvRepCount = findViewById(R.id.tvRepCount)
        tvTarget = findViewById(R.id.tvTarget)
        tvFeedback = findViewById(R.id.tvFeedback)

        tvTarget.text = "Tapşırıq: $targetReps dənə $exerciseName"

        db = AppDatabase.getInstance(this)
        repCounter = PushUpCounter()
        cameraExecutor = Executors.newSingleThreadExecutor()

        poseHelper = PoseLandmarkerHelper(
            context = this,
            listener = { result, imgW, imgH ->
                runOnUiThread {
                    overlayView.updateResult(result, imgW, imgH)
                    val landmarks = result.landmarks().firstOrNull()
                    if (landmarks != null) {
                        val repCompleted = repCounter.processFrame(landmarks)
                        tvRepCount.text = "${repCounter.repCount}"
                        tvFeedback.text = repCounter.getFeedback()

                        if (repCompleted) {
                            checkIfTargetReached()
                        }
                    }
                }
            },
            errorListener = { error ->
                runOnUiThread { Toast.makeText(this, error, Toast.LENGTH_SHORT).show() }
            }
        )

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun checkIfTargetReached() {
        if (repCounter.repCount >= targetReps && exerciseId != -1) {
            lifecycleScope.launch {
                db.exerciseDao().updateProgress(exerciseId, repCounter.repCount, true)
            }
            tvFeedback.text = "Təbriklər! Tapşırıq tamamlandı ✅"
        } else if (exerciseId != -1) {
            lifecycleScope.launch {
                db.exerciseDao().updateProgress(exerciseId, repCounter.repCount, false)
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy ->
                        poseHelper.detectLiveStream(imageProxy)
                    }
                }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
            overlayView.isFrontCamera = true

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageAnalysis
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Kamera başladıla bilmədi: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        poseHelper.close()
    }
}
