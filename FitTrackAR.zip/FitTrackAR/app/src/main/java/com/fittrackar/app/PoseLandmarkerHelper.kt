package com.fittrackar.app

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult

/**
 * MediaPipe Pose Landmarker-i idarə edən köməkçi sinif.
 * Model faylı: app/src/main/assets/pose_landmarker_lite.task
 * (Google-un rəsmi saytından yüklənməlidir - README-də link var)
 */
class PoseLandmarkerHelper(
    private val context: Context,
    private val listener: (result: PoseLandmarkerResult, imageWidth: Int, imageHeight: Int) -> Unit,
    private val errorListener: (String) -> Unit = {}
) {

    private var poseLandmarker: PoseLandmarker? = null

    init {
        setupPoseLandmarker()
    }

    private fun setupPoseLandmarker() {
        try {
            val baseOptionsBuilder = BaseOptions.builder()
                .setModelAssetPath("pose_landmarker_lite.task")
                .setDelegate(Delegate.GPU) // Sürət üçün GPU; dəstəklənməzsə CPU-ya keçir

            val options = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(baseOptionsBuilder.build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumPoses(1)
                .setMinPoseDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setMinPosePresenceConfidence(0.5f)
                .setResultListener(::onResult)
                .setErrorListener { e -> errorListener(e.message ?: "MediaPipe xətası") }
                .build()

            poseLandmarker = PoseLandmarker.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e(TAG, "GPU delegate uğursuz oldu, CPU-ya keçirilir", e)
            setupPoseLandmarkerCpuFallback()
        }
    }

    private fun setupPoseLandmarkerCpuFallback() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("pose_landmarker_lite.task")
                .setDelegate(Delegate.CPU)
                .build()

            val options = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumPoses(1)
                .setResultListener(::onResult)
                .setErrorListener { e -> errorListener(e.message ?: "MediaPipe xətası") }
                .build()

            poseLandmarker = PoseLandmarker.createFromOptions(context, options)
        } catch (e: Exception) {
            errorListener("Pose Landmarker yüklənmədi: ${e.message}")
        }
    }

    private var lastImageWidth = 0
    private var lastImageHeight = 0

    private fun onResult(result: PoseLandmarkerResult, input: com.google.mediapipe.framework.image.MPImage) {
        listener(result, lastImageWidth, lastImageHeight)
    }

    /** ImageAnalysis-dən gələn hər frame-i MediaPipe-ə göndərir */
    fun detectLiveStream(imageProxy: ImageProxy) {
        lastImageWidth = imageProxy.width
        lastImageHeight = imageProxy.height

        val bitmap = imageProxy.toBitmap()
        val mpImage = BitmapImageBuilder(bitmap).build()
        val timestampMs = System.currentTimeMillis()

        poseLandmarker?.detectAsync(mpImage, timestampMs)
        imageProxy.close()
    }

    fun close() {
        poseLandmarker?.close()
        poseLandmarker = null
    }

    companion object {
        private const val TAG = "PoseLandmarkerHelper"
    }
}

/**
 * ImageProxy -> Bitmap çevirmə (YUV_420_888 formatından).
 * Qeyd: sadəlik üçün burada göstərilir; performans üçün RenderScript/RenderEffect
 * və ya ImageProxy.toBitmap() (CameraX 1.3+ built-in) istifadə edilə bilər.
 */
private fun ImageProxy.toBitmap(): Bitmap {
    val yBuffer = planes[0].buffer
    val uBuffer = planes[1].buffer
    val vBuffer = planes[2].buffer

    val ySize = yBuffer.remaining()
    val uSize = uBuffer.remaining()
    val vSize = vBuffer.remaining()

    val nv21 = ByteArray(ySize + uSize + vSize)
    yBuffer.get(nv21, 0, ySize)
    vBuffer.get(nv21, ySize, vSize)
    uBuffer.get(nv21, ySize + vSize, uSize)

    val yuvImage = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, width, height, null)
    val out = java.io.ByteArrayOutputStream()
    yuvImage.compressToJpeg(android.graphics.Rect(0, 0, width, height), 90, out)
    val imageBytes = out.toByteArray()
    return android.graphics.BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
}
