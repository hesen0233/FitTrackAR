package com.fittrackar.app

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.atan2

/**
 * MediaPipe Pose Landmarker indeksləri (33 nöqtə):
 * 11 = Sol çiyin, 13 = Sol dirsək, 15 = Sol bilək
 * 12 = Sağ çiyin, 14 = Sağ dirsək, 16 = Sağ bilək
 * 23 = Sol bel,   24 = Sağ bel
 * 25 = Sol diz,   27 = Sol ayaq biləyi
 */
object PoseLandmarks {
    const val LEFT_SHOULDER = 11
    const val RIGHT_SHOULDER = 12
    const val LEFT_ELBOW = 13
    const val RIGHT_ELBOW = 14
    const val LEFT_WRIST = 15
    const val RIGHT_WRIST = 16
    const val LEFT_HIP = 23
    const val RIGHT_HIP = 24
    const val LEFT_KNEE = 25
    const val RIGHT_KNEE = 26
    const val LEFT_ANKLE = 27
    const val RIGHT_ANKLE = 28
}

/**
 * Üç nöqtə arasındakı bucağı (dərəcə ilə) hesablayır.
 * `mid` - bucağın təpə nöqtəsi (məs: dirsək)
 * Nümunə: calculateAngle(çiyin, dirsək, bilək) -> qol bucağı
 */
fun calculateAngle(a: NormalizedLandmark, mid: NormalizedLandmark, c: NormalizedLandmark): Double {
    val angleRad = atan2((c.y() - mid.y()).toDouble(), (c.x() - mid.x()).toDouble()) -
            atan2((a.y() - mid.y()).toDouble(), (a.x() - mid.x()).toDouble())
    var angleDeg = Math.toDegrees(angleRad)
    angleDeg = abs(angleDeg)
    if (angleDeg > 180) angleDeg = 360 - angleDeg
    return angleDeg
}

enum class RepState { UP, DOWN }

/**
 * Push-up sayğacı: çiyin-dirsək-bilək bucağını izləyərək
 * düzgün "aşağı-yuxarı" hərəkətini tanıyır.
 *
 * Məntiq:
 *  - Qol bucağı > 160° -> bədən YUXARI (başlanğıc/bitiş vəziyyəti)
 *  - Qol bucağı < 90°  -> bədən AŞAĞI (düzgün push-up dərinliyi)
 *  - UP -> DOWN -> UP tam dövrü 1 təkrar sayılır
 *  - Əgər bucaq 90-160 arası qalıb UP-a qayıtmasa, sayılmır (natamam hərəkət)
 */
class PushUpCounter(
    private val downThreshold: Double = 90.0,
    private val upThreshold: Double = 160.0
) {
    var repCount = 0
        private set

    private var state = RepState.UP
    private var lastFeedback: String = "Başlamağa hazırsınız"

    fun getFeedback() = lastFeedback

    /**
     * Hər frame üçün çağırılır. Landmarks tam siyahı olmalıdır (33 nöqtə).
     * @return true əgər bu frame-də yeni bir təkrar sayıldısa
     */
    fun processFrame(landmarks: List<NormalizedLandmark>): Boolean {
        if (landmarks.size < 17) return false

        val leftAngle = calculateAngle(
            landmarks[PoseLandmarks.LEFT_SHOULDER],
            landmarks[PoseLandmarks.LEFT_ELBOW],
            landmarks[PoseLandmarks.LEFT_WRIST]
        )
        val rightAngle = calculateAngle(
            landmarks[PoseLandmarks.RIGHT_SHOULDER],
            landmarks[PoseLandmarks.RIGHT_ELBOW],
            landmarks[PoseLandmarks.RIGHT_WRIST]
        )
        // İki qolun ortalaması - daha stabil nəticə üçün
        val avgAngle = (leftAngle + rightAngle) / 2.0

        var repCompleted = false

        when (state) {
            RepState.UP -> {
                if (avgAngle < downThreshold) {
                    state = RepState.DOWN
                    lastFeedback = "Aşağı vəziyyət qeydə alındı, indi qalxın"
                } else {
                    lastFeedback = "Aşağı enin (${avgAngle.toInt()}°)"
                }
            }
            RepState.DOWN -> {
                if (avgAngle > upThreshold) {
                    state = RepState.UP
                    repCount++
                    repCompleted = true
                    lastFeedback = "Əla! Sayğac: $repCount"
                } else {
                    lastFeedback = "Yuxarı qalxın (${avgAngle.toInt()}°)"
                }
            }
        }

        return repCompleted
    }

    fun reset() {
        repCount = 0
        state = RepState.UP
        lastFeedback = "Başlamağa hazırsınız"
    }
}

/**
 * Squat üçün oxşar sayğac - bel/diz/ayaq biləyi bucağından istifadə edir.
 * Eyni state-machine məntiqi, fərqli bucaq və nöqtələr.
 */
class SquatCounter(
    private val downThreshold: Double = 100.0,
    private val upThreshold: Double = 160.0
) {
    var repCount = 0
        private set
    private var state = RepState.UP

    fun processFrame(landmarks: List<NormalizedLandmark>): Boolean {
        if (landmarks.size < 29) return false

        val leftAngle = calculateAngle(
            landmarks[PoseLandmarks.LEFT_HIP],
            landmarks[PoseLandmarks.LEFT_KNEE],
            landmarks[PoseLandmarks.LEFT_ANKLE]
        )
        val rightAngle = calculateAngle(
            landmarks[PoseLandmarks.RIGHT_HIP],
            landmarks[PoseLandmarks.RIGHT_KNEE],
            landmarks[PoseLandmarks.RIGHT_ANKLE]
        )
        val avgAngle = (leftAngle + rightAngle) / 2.0

        var repCompleted = false
        when (state) {
            RepState.UP -> if (avgAngle < downThreshold) state = RepState.DOWN
            RepState.DOWN -> if (avgAngle > upThreshold) {
                state = RepState.UP
                repCount++
                repCompleted = true
            }
        }
        return repCompleted
    }

    fun reset() {
        repCount = 0
        state = RepState.UP
    }
}
