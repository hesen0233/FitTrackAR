package com.fittrackar.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fittrackar.app.data.Exercise

class ExerciseAdapter(
    private var items: List<Exercise>,
    private val onStartClicked: (Exercise) -> Unit
) : RecyclerView.Adapter<ExerciseAdapter.ExerciseViewHolder>() {

    inner class ExerciseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tvExerciseName)
        val progress: TextView = view.findViewById(R.id.tvProgress)
        val checkBox: CheckBox = view.findViewById(R.id.cbCompleted)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExerciseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_exercise, parent, false)
        return ExerciseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExerciseViewHolder, position: Int) {
        val exercise = items[position]
        holder.title.text = exercise.name
        holder.progress.text = "${exercise.completedReps}/${exercise.targetReps}"
        holder.checkBox.isChecked = exercise.isCompleted // ✅ quş işarəsi
        holder.checkBox.isClickable = false

        holder.itemView.setOnClickListener {
            if (!exercise.isCompleted) onStartClicked(exercise)
        }
    }

    override fun getItemCount() = items.size

    fun updateList(newItems: List<Exercise>) {
        items = newItems
        notifyDataSetChanged()
    }
}
