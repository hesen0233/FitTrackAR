package com.fittrackar.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fittrackar.app.data.AppDatabase
import com.fittrackar.app.data.Exercise
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ExerciseAdapter
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = AppDatabase.getInstance(this)
        recyclerView = findViewById(R.id.recyclerViewExercises)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = ExerciseAdapter(emptyList()) { exercise ->
            // Məşq ekranına keç, hansı hərəkət olduğunu ötür
            val intent = Intent(this, WorkoutActivity::class.java).apply {
                putExtra("exercise_id", exercise.id)
                putExtra("exercise_name", exercise.name)
                putExtra("target_reps", exercise.targetReps)
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        seedDefaultProgramIfEmpty()
        observeExercises()
    }

    override fun onResume() {
        super.onResume()
        observeExercises() // WorkoutActivity-dən qayıdanda siyahını yenilə
    }

    private fun seedDefaultProgramIfEmpty() {
        lifecycleScope.launch {
            val dao = db.exerciseDao()
            // Yalnız ilk açılışda default proqram əlavə olunur (real layihədə flag saxlanmalıdır)
        }
    }

    private fun observeExercises() {
        lifecycleScope.launch {
            db.exerciseDao().getAllExercises().collect { list ->
                if (list.isEmpty()) {
                    insertDefaultProgram()
                } else {
                    adapter.updateList(list)
                }
            }
        }
    }

    private suspend fun insertDefaultProgram() {
        val dao = db.exerciseDao()
        dao.insert(Exercise(name = "Push-up", targetReps = 10))
        dao.insert(Exercise(name = "Squat", targetReps = 15))
    }
}
