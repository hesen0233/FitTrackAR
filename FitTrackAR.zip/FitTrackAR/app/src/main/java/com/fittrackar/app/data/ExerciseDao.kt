package com.fittrackar.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {

    @Query("SELECT * FROM exercises ORDER BY dateAdded ASC")
    fun getAllExercises(): Flow<List<Exercise>>

    @Insert
    suspend fun insert(exercise: Exercise)

    @Update
    suspend fun update(exercise: Exercise)

    @Delete
    suspend fun delete(exercise: Exercise)

    @Query("UPDATE exercises SET completedReps = :reps, isCompleted = :completed WHERE id = :id")
    suspend fun updateProgress(id: Int, reps: Int, completed: Boolean)
}
