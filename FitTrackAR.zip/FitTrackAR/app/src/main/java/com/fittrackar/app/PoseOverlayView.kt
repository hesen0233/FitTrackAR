package com.fittrackar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult
import kotlin.math.max
import kotlin.math.min

/**
 * Oyunlardakı "ESP" effektini xatırladan skelet overlay.
 * Kameranın üzərinə (PreviewView-un üstünə) yerləşdirilir.
 */
class PoseOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var result: PoseLandmarkerResult? = null
    private var imageWidth = 1
    private var imageHeight = 1

    // Kamera ön kamera olduğu üçün güzgü effekti tələb oluna bilər
    var isFrontCamera = true

    private val jointPaint = Paint().apply {
        color = Color.parseColor("#00E5FF") // ESP mavi/cyan
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val bonePaint = Paint().apply {
        color = Color.parseColor("#39FF14") // ESP yaşıl
        style = Paint.Style.STROKE
        strokeWidth = 6f
        isAntiAlias = true
    }

    private val boxPaint = Paint().apply {
        color = Color.parseColor("#FFEA00") // ESP sarı box
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }

    // MediaPipe Pose Landmarker-in 33 nöqtəsi arasındakı sümük bağlantıları
    private val connections = listOf(
        // üz/baş
        0 to 1, 1 to 2, 2 to 3, 3 to 7, 0 to 4, 4 to 5, 5 to 6, 6 to 8,
        // çiyinlər və qollar
        11 to 12, 11 to 13, 13 to 15, 12 to 14, 14 to 16,
        // gövdə
        11 to 23, 12 to 24, 23 to 24,
        // ayaqlar
        23 to 25, 25 to 27, 27 to 29, 29 to 31,
        24 to 26, 26 to 28, 28 to 30, 30 to 32
    )

    fun updateResult(newResult: PoseLandmarkerResult, imgW: Int, imgH: Int) {
        result = newResult
        imageWidth = max(imgW, 1)
        imageHeight = max(imgH, 1)
        invalidate()
    }

    fun clear() {
        result = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val landmarks: List<NormalizedLandmark> = result?.landmarks()?.firstOrNull() ?: return
        if (landmarks.isEmpty()) return

        val scaleX = width.toFloat() / imageWidth
        val scaleY = height.toFloat() / imageHeight
        // Preview adətən CENTER_CROP olduğundan böyük ölçəkdən istifadə edirik
        val scale = max(scaleX, scaleY)
        val offsetX = (width - imageWidth * scale) / 2f
        val offsetY = (height - imageHeight * scale) / 2f

        fun mapX(x: Float): Float {
            val px = x * imageWidth * scale + offsetX
            return if (isFrontCamera) width - px else px
        }
        fun mapY(y: Float): Float = y * imageHeight * scale + offsetY

        // 1) Sümük xətləri (skelet)
        connections.forEach { (startIdx, endIdx) ->
            val p1 = landmarks.getOrNull(startIdx) ?: return@forEach
            val p2 = landmarks.getOrNull(endIdx) ?: return@forEach
            canvas.drawLine(mapX(p1.x()), mapY(p1.y()), mapX(p2.x()), mapY(p2.y()), bonePaint)
        }

        // 2) Oynaq nöqtələri
        landmarks.forEach { lm ->
            canvas.drawCircle(mapX(lm.x()), mapY(lm.y()), 9f, jointPaint)
        }

        // 3) Bədəni əhatə edən ESP "box"
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE; var maxY = Float.MIN_VALUE
        landmarks.forEach { lm ->
            val px = mapX(lm.x()); val py = mapY(lm.y())
            minX = min(minX, px); minY = min(minY, py)
            maxX = max(maxX, px); maxY = max(maxY, py)
        }
        canvas.drawRect(minX - 20f, minY - 20f, maxX + 20f, maxY + 20f, boxPaint)
    }
}
