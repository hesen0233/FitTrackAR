# FitTrack AR — Quraşdırma Təlimatı

## 1. Layihəni Android Studio-da açmaq
1. Android Studio-nu aç → **File > Open** → bu qovluğu (`FitTrackAR`) seç.
2. Gradle sync avtomatik başlayacaq (internet lazımdır, ilk dəfə bir neçə dəqiqə çəkə bilər).

## 2. MediaPipe Pose Landmarker modelini əlavə etmək (VACİB!)
Kod `pose_landmarker_lite.task` adlı model faylını `assets` qovluğundan axtarır. Bu fayl ölçüsünə görə buraya daxil edilməyib, sən özün yükləməlisən:

1. Bu linkə get: https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task
2. Yüklənən faylı bu qovluğa qoy:
   `app/src/main/assets/pose_landmarker_lite.task`
3. Əgər `assets` qovluğu görünmürsə, `app/src/main` üzərinə sağ klik → New > Directory > "assets" yaz.

(Daha sürətli/dəqiq versiya istəsən `pose_landmarker_full.task` və ya `pose_landmarker_heavy.task` də istifadə edə bilərsən — həmin URL-də `lite` sözünü dəyişməklə.)

## 3. APK yaratmaq
1. Yuxarı menyudan: **Build > Build Bundle(s)/APK(s) > Build APK(s)**
2. Build bitəndə aşağıda "locate" linki çıxacaq → `app/build/outputs/apk/debug/app-debug.apk`
3. Bu faylı telefonuna köçür (USB, Google Drive, və s.) və quraşdır (naməlum mənbələrə icazə tələb oluna bilər).

## 4. Test etmək
- Tətbiqi aç → Ana ekranda "Push-up" və "Squat" tapşırıqları görünəcək.
- Üzərinə basanda kamera açılır, bədənin üzərində yaşıl skelet xətləri və sarı "ESP box" görünəcək.
- Push-up edərkən qolun bucağı 160°-dən 90°-yə düşəndə "aşağı", sonra yenidən 160°-ə qalxanda 1 təkrar sayılır.
- Tapşırıq (10/10) tamamlananda checklist-də ✅ işarəsi avtomatik qoyulur.

## Qeydlər / Növbəti addımlar
- Hazırkı kod **push-up** və **squat** üçün işləyir; yeni hərəkət (məs. jumping jack) əlavə etmək üçün `RepCounter.kt`-ə oxşar bir sinif yazmaq kifayətdir.
- `ImageProxy.toBitmap()` funksiyası sadə JPEG-əsaslı çevrilmədir — performans üçün gələcəkdə `RenderEffect` və ya YUV-to-RGB native kodla əvəz edilə bilər.
- GPU delegate bəzi köhnə cihazlarda dəstəklənməyə bilər — kod avtomatik CPU-ya keçir.
